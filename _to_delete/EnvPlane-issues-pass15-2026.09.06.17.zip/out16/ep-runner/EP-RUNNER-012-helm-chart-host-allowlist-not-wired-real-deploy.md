# EP-RUNNER-012 — Allowlist хостов Helm chart-репозитория проверяется только в команде `validate_helm_chart`, не в реальном пути деплоя

| Поле | Значение |
|---|---|
| Severity | High |
| Направление | security (SSRF / supply chain) |
| Репозиторий | `runner` |
| Затронутый слой | `internal/runner/runtime.go:996` (единственная точка вызова `validateRunnerHelmChart`), `:1293-1322` (`runnerHelmChartHostAllowed`), `internal/orchestrator/orchestrator.go` (`CLIHelmExecutor.UpgradeInstall`) |
| Зависит от | Смежная область с [EP-RUNNER-005](../ep-runner/EP-RUNNER-005-validate-helm-chart-render-release-plan-bypass-ssrf.md) (уже фиксировал SSRF через render release plan) |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `bf7de8c` — вызов `validateRunnerHelmChart` встречается ровно в одном месте (`grep` по всему модулю) |

## Контекст

`runnerHelmChartHostAllowed` (`internal/runner/runtime.go:1310-1322`) реализует allowlist хостов для прямых сетевых ссылок на Helm-чарты (`oci://`, `http://`, `https://`):

```go
func runnerHelmChartHostAllowed(chartRef string, allowedHosts []string) bool {
	parsed, err := url.Parse(strings.TrimSpace(chartRef))
	if err != nil || (parsed.Scheme != "oci" && parsed.Scheme != "http" && parsed.Scheme != "https") {
		return true
	}
	host := strings.ToLower(strings.TrimSpace(parsed.Hostname()))
	if host == "" || len(allowedHosts) == 0 {
		return false
	}
	for _, allowed := range allowedHosts {
		if host == strings.ToLower(strings.TrimSpace(allowed)) {
			return true
		}
	}
	return false
}
```

Единственный вызывающий — `validateRunnerHelmChartWithConfig` → `validateRunnerHelmChart` (`internal/runner/runtime.go:996`), которая, судя по имени и контексту вызова, срабатывает для команды типа `validate_helm_chart` (отдельная, вероятно, превентивная/dry-run операция). Поиском по всему модулю (`grep -rn "validateRunnerHelmChart\b"`) подтверждено, что это единственная точка вызова во всём репозитории — реальный путь деплоя, `CLIHelmExecutor.UpgradeInstall` (`internal/orchestrator/orchestrator.go:126`), эту функцию не вызывает и, соответственно, allowlist хостов не применяет к чарту, который реально устанавливается.

Это тот же архитектурный анти-паттерн, который неоднократно фиксировался в этом проекте ("защитная/подписанная проверка выполняется, но реальный путь исполнения не использует её результат") — здесь конкретно: SSRF/supply-chain guard существует и корректно реализован, но подключён только к вспомогательной команде проверки, а не к команде, которая реально тянет и разворачивает чарт.

**Сценарий отказа:** если control-plane (скомпрометированный, либо содержащий баг) отправляет runner'у команду `create`/`recreate` (не `validate_helm_chart`) с `ChartRef`, указывающим на непроверенный/недоверенный хост, `CLIHelmExecutor.UpgradeInstall` выполнит `helm upgrade --install` с этим `ChartRef` напрямую, без обращения к `runnerHelmChartHostAllowed` — то есть настоящий деплой не защищён этим guard'ом вовсе, только его "холостая" dry-run версия.

## Требуемая реализация

1. Подтвердить (через чтение полного тела `CLIHelmExecutor.UpgradeInstall` и всего пути от получения команды `create`/`recreate` до вызова `helm`), действительно ли `ChartRef`/`chartRef` из команды деплоя проходит через `runnerHelmChartHostAllowed`/`validateRunnerHelmChart` где-либо ещё, кроме строки 996 — если да, этот тикет закрывается как false positive с указанием найденного пути.
2. Если подтверждается отсутствие вызова — вызывать `runnerHelmChartHostAllowed` (или полностью `validateRunnerHelmChartWithConfig`) непосредственно перед выполнением `helm upgrade --install`/`helm pull` в реальном пути `create`/`recreate`, а не только в `validate_helm_chart`.
3. Добавить интеграционный тест, который отправляет runner'у команду `create` с `ChartRef` на неаллоулистенный хост и проверяет, что деплой отклоняется до вызова `helm`.

## Что НЕ входит в этот тикет

Redesign самого allowlist-механизма (`runnerHelmChartHostAllowed`) — он корректен по своей логике; проблема исключительно в неполном подключении к реальному пути исполнения.

## Критерии приёмки

- Команда `create`/`recreate` с `ChartRef` на неразрешённый хост отклоняется runner'ом до вызова `helm`, с тем же поведением, что и `validate_helm_chart`.
- Новый интеграционный тест подтверждает это для обоих типов команд.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/runner

Задача: internal/runner/runtime.go — функция runnerHelmChartHostAllowed (allowlist хостов для
прямых сетевых Helm chart-ссылок oci://, http://, https://) вызывается только из
validateRunnerHelmChart, единственная точка вызова которой — строка 996, судя по контексту
относящаяся к команде validate_helm_chart. Реальный путь деплоя, CLIHelmExecutor.UpgradeInstall
(internal/orchestrator/orchestrator.go), эту функцию не вызывает.

Нужно: сначала подтвердить чтением полного пути от получения команды create/recreate до вызова
helm, действительно ли ChartRef проходит проверку allowlist где-либо ещё. Если нет — подключить
runnerHelmChartHostAllowed (или validateRunnerHelmChartWithConfig целиком) непосредственно перед
выполнением helm upgrade --install/helm pull в реальном пути деплоя, а не только в
validate_helm_chart. Добавить интеграционный тест: команда create с ChartRef на неаллоулистенный
хост должна отклоняться до вызова helm.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
