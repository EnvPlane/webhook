# EP-RUNNER-011 — Аддендум к EP-RUNNER-001: тот же паттерн self-referential проверки повторился в поле `namespaces`/`kinds` инвентарной проверки

| Поле | Значение |
|---|---|
| Severity | High |
| Направление | security |
| Репозиторий | `runner` |
| Затронутый слой | `internal/runner/runtime.go:1112-1118` (построение `namespaces`/`kinds`), `:1119` (`domain.VerifyReleasePlanReference`) |
| Зависит от | [EP-RUNNER-001](../ep-runner/EP-RUNNER-001-releaseplan-identity-self-check.md) — тот же класс бага, устранённый для identity-проверки, но не для инвентарной |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `bf7de8c`. Статус EP-RUNNER-001: **ИСПРАВЛЕНО для identity, НЕ ИСПРАВЛЕНО структурно для inventory-guard** |

## Контекст

EP-RUNNER-001 фиксировал, что identity-проверка сравнивала `ReleasePlan` сам с собой (self-check вместо сравнения с независимым источником истины — реальной конфигурацией runner'а). Судя по текущему коду, для identity это исправлено: теперь используется независимый источник `cfg.ProjectID`/`cfg.ClusterID`/`cfg.RunnerID` (конфигурация самого runner-процесса), а не поля из проверяемого `ReleasePlan`:

```go
// internal/runner/runtime.go:1118
if err := domain.VerifyReleasePlanReference(*command.ReleasePlan, ref, publicKey,
    domain.ReleasePlanRunnerIdentity{TenantID: tenantID, ProjectID: cfg.ProjectID, ClusterID: cfg.ClusterID, RunnerID: cfg.RunnerID},
    namespaces, kinds); err != nil {
```

Однако **точно тот же структурный баг** воспроизведён в этой же функции для другого параметра той же проверки — `namespaces`/`kinds`:

```go
// internal/runner/runtime.go:1112-1117
namespaces := make([]string, 0, len(command.ReleasePlan.RenderedResources))
kinds := make([]string, 0, len(command.ReleasePlan.RenderedResources))
for _, resource := range command.ReleasePlan.RenderedResources {
    namespaces = appendUnique(namespaces, resource.Namespace)
    kinds = appendUnique(kinds, resource.Kind)
}
```

`namespaces`/`kinds` строятся **из того же самого `command.ReleasePlan.RenderedResources`**, который затем передаётся в `VerifyReleasePlanReference` как проверяемый объект (`*command.ReleasePlan`). То есть инвентарный guard (по всей видимости, задуманный как ограничение: "разрешённые namespace/kinds для этого runner'а/проекта") на самом деле сверяет `RenderedResources` со списком, **построенным из этого же самого `RenderedResources`**, — проверка тавтологична и не может провалиться ни при каком содержимом плана: злоумышленник, подделавший (либо легитимно получивший подписанный, но для другого проекта) `RenderedResources` с произвольными namespace/kinds, автоматически проходит эту проверку, потому что список "разрешённых" значений всегда равен фактическому содержимому.

Это ровно та же категория бага, что и в EP-RUNNER-001 (self-referential verification), просто в другом поле той же функции — что показывает, что баг не был устранён на уровне класса/паттерна, а был точечно пропатчен только в одном из двух мест, где он присутствовал.

## Требуемая реализация

1. Определить независимый от `command.ReleasePlan.RenderedResources` источник истины для допустимых `namespaces`/`kinds` — например, ожидаемый namespace проекта/окружения (`cfg`/`command.Environment.Namespace`) и явный allowlist разрешённых `kinds` (аналог `runnerProjectConfigAllowedKeys`, но для Kubernetes `kind`).
2. Передавать в `domain.VerifyReleasePlanReference` эти независимо вычисленные значения вместо построенных из проверяемого плана.
3. Провести ревизию `domain.VerifyReleasePlanReference` (репозиторий `contracts`) на предмет того, как параметры `namespaces`/`kinds` реально используются внутри — если функция ожидает "белый список, с которым нужно свериться", а не "то, что фактически присутствует", вызывающий код (runner) обязан передавать первое, а не второе.
4. Добавить unit-тест, который передаёт `RenderedResources` с namespace/kind, заведомо не входящими в реальный allowlist проекта, и проверяет, что `VerifyReleasePlanReference` отклоняет план.

## Что НЕ входит в этот тикет

Полный редизайн `VerifyReleasePlanReference`/протокола `ReleasePlan` — только устранение конкретной тавтологичной проверки `namespaces`/`kinds`.

## Критерии приёмки

- `namespaces`/`kinds`, передаваемые в `VerifyReleasePlanReference`, вычисляются из источника, независимого от проверяемого `command.ReleasePlan.RenderedResources`.
- Новый тест с намеренно "чужими" namespace/kind в `RenderedResources` подтверждает отказ.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/runner

Задача: аддендум к EP-RUNNER-001. internal/runner/runtime.go:1112-1119 — параметры namespaces и
kinds, передаваемые в domain.VerifyReleasePlanReference, строятся циклом по
command.ReleasePlan.RenderedResources — том же самом объекте, который затем передаётся в эту
функцию как *command.ReleasePlan для проверки. Проверка тавтологична: "разрешённый" список
namespace/kind всегда равен фактическому содержимому проверяемого плана, поэтому не может
отклонить план ни при каком его содержимом. Identity-параметры той же функции (TenantID/ProjectID/
ClusterID/RunnerID) уже исправлены и берутся из независимого cfg, а не из плана — namespaces/kinds
остались непочиненными как отдельный экземпляр того же класса бага (self-referential verification).

Нужно: вычислять namespaces/kinds из независимого от RenderedResources источника (ожидаемый
namespace проекта/окружения, allowlist разрешённых Kubernetes kind) и передавать эти значения в
VerifyReleasePlanReference вместо построенных из самого проверяемого плана. Проверить в
репозитории contracts, как VerifyReleasePlanReference использует эти параметры, чтобы вызывающий
код передавал корректный "источник истины". Добавить тест с namespace/kind, не входящими в
реальный allowlist, подтверждающий отказ.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
