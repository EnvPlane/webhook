# EP-ARCH-062 — `ListTenantIDs()` не устанавливает tenant/platform контекст RLS и молча возвращает пустой список под non-superuser ролью

| Поле | Значение |
|---|---|
| Severity | Critical |
| Направление | security / reliability |
| Репозиторий | `control-plane` |
| Затронутый слой | `internal/store/sql_project_store.go:63-77`, `internal/store/sql_bootstrap_session_store.go:74-88`, `internal/store/sql_remote_cluster_store.go:78-93`, `internal/store/tenant_tx.go` (`platformQueryRows`), `migrations/postgres/034_enable_tenant_rls.sql` |
| Зависит от | Новая находка 15-го прохода — обнаружена из-за пересечения с миграцией `034_enable_tenant_rls.sql`, добавленной уже после аудита, зафиксировавшего паттерн `DefaultTenantID` (EP-ARCH-054/055/056) |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `5d5e899` |

## Контекст

Миграция `migrations/postgres/034_enable_tenant_rls.sql` включает Row-Level Security с `FORCE ROW LEVEL SECURITY` на всех тенант-принадлежащих таблицах (`projects`, `remote_clusters`, `bootstrap_sessions` и др.), и политика такая:

```sql
CREATE POLICY %I ON %I USING (
  tenant_id = current_setting('envplane.tenant_id', true)
  OR current_setting('envplane.platform', true) = 'true'
)
```

То есть строка видна только если в текущей транзакции установлена сессионная переменная `envplane.tenant_id`, совпадающая со значением в строке, либо явно установлен `envplane.platform = true`. Обе переменные выставляются вспомогательными функциями в `internal/store/tenant_tx.go` (`tenantQueryRows`/`tenantQueryRow`/`tenantExec` — ставят `envplane.tenant_id`; `platformQueryRows` — ставит `envplane.platform = true`).

Три реализации `ListTenantIDs()` игнорируют оба этих канала и делают запрос напрямую через `s.db.Query(...)`:

```go
// internal/store/sql_project_store.go:63-77
func (s *SQLProjectStore) ListTenantIDs() ([]string, error) {
	rows, err := s.db.Query(`SELECT DISTINCT tenant_id FROM projects ORDER BY tenant_id`)
	...
}
```

Идентичный паттерн — в `sql_bootstrap_session_store.go:74-88` и `sql_remote_cluster_store.go:78-93`. Ни `envplane.tenant_id`, ни `envplane.platform` не установлены → для любой роли, не являющейся Postgres-суперпользователем (а под `FORCE ROW LEVEL SECURITY` это касается даже владельца таблицы, если он не superuser), `current_setting(..., true)` вернёт `NULL` для обеих переменных, и `WHERE`-условие политики окажется `NULL`, т.е. ложным для каждой строки. Результат — **`SELECT DISTINCT tenant_id FROM projects` без ошибки возвращает пустой список**, а не access-denied и не все тенанты.

**Сценарий отказа:** `ListTenantIDs()` — типичный вход для платформенных cron/batch задач, которые должны пройтись по всем тенантам (например, ежедневный пересчёт квот, TTL-обходы, сверка биллинга — по всей архитектуре `internal/jobs`/`internal/dr` многие фоновые процессы устроены именно как "получить список тенантов → обработать каждый"). Если такая задача подключается тем же пулом соединений, что и обычные API-запросы (не суперпользователем), она получает пустой список тенантов **без единой ошибки или предупреждения в логах** — обход просто ничего не делает, силентно, для абсолютно всех тенантов сразу. Это может месяцами оставаться незамеченным, пока кто-то не заметит, что квоты не пересчитываются или DR-верификация не покрывает никого.

## Требуемая реализация

1. Заменить прямой `s.db.Query(...)` в `ListTenantIDs()` во всех трёх реализациях (`sql_project_store.go`, `sql_bootstrap_session_store.go`, `sql_remote_cluster_store.go`) на `platformQueryRows(ctx, s.db, ...)` из `tenant_tx.go`, явно устанавливающий `envplane.platform = true` для этого межтенантного чтения.
2. Провести ревизию всех остальных мест в `internal/store`, где выполняется прямой `s.db.Query`/`s.db.Exec` в обход `tenantQueryRows`/`tenantQueryRow`/`tenantExec`/`platformQueryRows` — этот баг может быть не единственным экземпляром паттерна (например, любые другие "list across tenants" методы).
3. Добавить в `scripts/check-tenant-scope.sh` (или отдельный скрипт) проверку на использование `s.db.Query(`/`s.db.Exec(` напрямую внутри `internal/store/*.go`, минуя `tenant_tx.go`-хелперы, а не только diff-проверку на уровне `internal/server`.
4. Добавить интеграционный тест против реальной Postgres с включённым RLS (не superuser-роль), который вызывает `ListTenantIDs()` при нескольких существующих тенантах и проверяет, что возвращается полный список, а не пустой.

## Что НЕ входит в этот тикет

- Полный аудит всех SQL-стораджей на предмет использования RLS-хелперов — только `ListTenantIDs()` в трёх перечисленных файлах входит явно; остальное — по итогам пункта 2 требуемой реализации, отдельными тикетами при обнаружении.
- Проверка того, под какой именно ролью подключается приложение в проде (superuser бы обходил RLS полностью, что отдельная и не менее серьёзная проблема, но не предмет этого тикета).

## Критерии приёмки

- Все три реализации `ListTenantIDs()` используют `platformQueryRows` (или эквивалентный хелпер, явно устанавливающий `envplane.platform=true`).
- Новый интеграционный тест против настоящей Postgres с `FORCE ROW LEVEL SECURITY` и non-superuser ролью подтверждает, что `ListTenantIDs()` возвращает полный список тенантов.
- CI-скрипт обнаруживает будущие прямые `s.db.Query`/`s.db.Exec` в `internal/store/*.go` в обход `tenant_tx.go`.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/control-plane

Задача: internal/store/sql_project_store.go:63-77, sql_bootstrap_session_store.go:74-88 и
sql_remote_cluster_store.go:78-93 — метод ListTenantIDs() во всех трёх реализациях вызывает
s.db.Query("SELECT DISTINCT tenant_id FROM ...") напрямую, минуя хелперы tenant_tx.go
(tenantQueryRows/tenantQueryRow/tenantExec/platformQueryRows). Миграция
migrations/postgres/034_enable_tenant_rls.sql включила FORCE ROW LEVEL SECURITY с политикой
"tenant_id = current_setting('envplane.tenant_id', true) OR current_setting('envplane.platform', true) = 'true'".
Поскольку ни одна из этих сессионных переменных в ListTenantIDs() не выставляется, под
non-superuser ролью политика ложна для каждой строки, и метод молча возвращает пустой список
без единой ошибки — это ломает межтенантные batch-задачи (пересчёт квот, TTL-обходы,
DR-верификация), которые используют ListTenantIDs() как точку входа для обхода всех тенантов.

Нужно:
1. Заменить s.db.Query(...) на platformQueryRows(ctx, s.db, ...) во всех трёх файлах, явно
   устанавливая envplane.platform=true для этого межтенантного чтения.
2. Проверить internal/store на другие прямые вызовы s.db.Query/s.db.Exec в обход
   tenant_tx.go-хелперов.
3. Расширить scripts/check-tenant-scope.sh (или добавить отдельный скрипт) проверкой на прямые
   SQL-вызовы в internal/store/*.go в обход tenant_tx.go.
4. Добавить интеграционный тест против реальной Postgres с включённым RLS и non-superuser ролью,
   создающий несколько тенантов и проверяющий, что ListTenantIDs() возвращает их всех.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
