# EP-ARCH-063 — Аддендум к EP-ARCH-054: `agentHeartbeat` всё ещё использует unscoped `bootstrapSessions.Get`/`projects.GetProject`

| Поле | Значение |
|---|---|
| Severity | High |
| Направление | security |
| Репозиторий | `control-plane` |
| Затронутый слой | `internal/server/server_agent_runtime.go:437-475` (`agentHeartbeat`) |
| Зависит от | [EP-ARCH-054](../ep-arch/EP-ARCH-054-bootstrap-session-tenant-isolation.md) — этот тикет фиксирует, что требуемая в EP-ARCH-054 ревизия call site'ов не завершена |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `5d5e899` — статус EP-ARCH-054: **ЧАСТИЧНО ИСПРАВЛЕНО** |

## Контекст

EP-ARCH-054 требовал убрать unscoped-методы `BootstrapSessionStore` (`GetByProject`, `Save`, `UpdateDataAtomically`, `DeleteByProject`) и провести ревизию всех call site в `internal/server`, заменив их на `*ForTenant`-варианты. Проверка 15-го прохода показывает, что путь `POST /api/v1/agents/heartbeat` (`agentHeartbeat`, `internal/server/server_agent_runtime.go:437-475`) остался нетронутым:

```go
// internal/server/server_agent_runtime.go:437-475
if projectID != "" {
    now := time.Now().UTC()
    project, err := s.projects.GetProject(projectID)        // unscoped
    ...
    session, sessionErr := s.bootstrapSessions.Get(projectID) // unscoped
    ...
    if _, updateErr := s.bootstrapSessions.Update(projectID, app.BootstrapSessionUpdate{StepData: stepData}); updateErr != nil { // unscoped
```

Это тот же публичный, аутентифицированный только одноразовым runtime-токеном (не сессией пользователя) эндпоинт, для которого EP-ARCH-054 явно требовал резолва тенанта — но здесь по-прежнему используются `s.projects.GetProject` и `s.bootstrapSessions.Get`/`Update` без `tenantID`, то есть при коллизии `projectID` между двумя тенантами heartbeat одного arendatora читает/пишет bootstrap-состояние в бакет `DefaultTenantID`, разделяемый со всеми остальными тенантами с тем же `projectID` — ровно сценарий эксплуатации, описанный в EP-ARCH-054, но конкретно для heartbeat-пути.

## Требуемая реализация

1. В `agentHeartbeat` резолвить `tenantID` проекта (например, через `s.projects.ResolveProjectTenant`/аналогичный метод, уже упомянутый в EP-ARCH-054 контексте `internal/app/project_service.go:87-115`) до вызова `s.projects.GetProject`/`s.bootstrapSessions.Get`/`Update`.
2. Заменить эти три unscoped-вызова на их `*ForTenant`-эквиваленты.
3. Добавить этот путь явно в тест EP-ARCH-054 (два тенанта с одинаковым `projectID`, оба шлют heartbeat) — либо расширить существующий тест, либо добавить кейс.
4. Провести ту же проверку по оставшимся файлам, перечисленным в EP-ARCH-054 (`server_projects.go`, `server_ai.go`, `server_release_plans.go`, `server_secret_materialization_runtime.go`) — не входит структурно в этот тикет объёмом, но стоит явно отметить в PR, что именно перепроверено.

## Что НЕ входит в этот тикет

Полная повторная ревизия всех call site из EP-ARCH-054 — этот тикет фиксирует конкретно `agentHeartbeat` как подтверждённый пропуск; остальные файлы предполагаются либо исправленными, либо требуют отдельной проверки при следующем проходе.

## Критерии приёмки

- `agentHeartbeat` резолвит реальный `tenantID` и использует `*ForTenant`-варианты для `GetProject`, `bootstrapSessions.Get`, `bootstrapSessions.Update`.
- Тест на два тенанта с одинаковым `projectID`, оба отправляют heartbeat — подтверждает отсутствие кросс-тенантной записи/чтения.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/control-plane

Задача: аддендум к ранее выданному тикету EP-ARCH-054 (устранение unscoped доступа к
bootstrap-сессиям по tenantID). Проверка показала, что internal/server/server_agent_runtime.go:437-475
(функция agentHeartbeat, обслуживающая POST /api/v1/agents/heartbeat) не была затронута
исправлением: там по-прежнему вызываются s.projects.GetProject(projectID) и
s.bootstrapSessions.Get(projectID)/Update(projectID, ...) без tenantID. При коллизии projectID
между двумя тенантами heartbeat одного арендатора читает и пишет bootstrap-состояние в общий
default-tenant бакет, разделяемый с другим тенантом с тем же projectID.

Нужно: резолвить tenantID проекта в agentHeartbeat до этих вызовов (аналогично остальным местам,
исправленным по EP-ARCH-054) и заменить на *ForTenant-варианты. Добавить или расширить
интеграционный тест на два тенанта с одинаковым projectID, оба отправляют heartbeat — убедиться
в отсутствии кросс-тенантной утечки.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
