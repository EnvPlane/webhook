# EP-ARCH-064 — Живые «deprecated» вебхук-приёмники внутри control-plane обходят всё усиление безопасности, сделанное в репозитории `webhook`

| Поле | Значение |
|---|---|
| Severity | Critical |
| Направление | security |
| Репозиторий | `control-plane` (использует устаревшую версию `webhook`) |
| Затронутый слой | `internal/server/server.go:1141-1142` (регистрация роутов), `internal/server/server.go:2562` (auth-исключение), `internal/server/server.go:7558-7620+` (`gitlabWebhook`, `githubWebhook`, `githubWebhookPoC`), `go.mod:11` (`github.com/envplane/webhook v0.1.1`) |
| Зависит от | Обесценивает эффект всей серии тикетов [EP-HOOK-001..010](../ep-hook/) — те исправления применены только в отдельном сервисе `webhook`, а не в этом параллельном пути |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `5d5e899` |

## Контекст

В control-plane по-прежнему зарегистрированы и полностью функциональны собственные вебхук-приёмники:

```go
// internal/server/server.go:1141-1143
mux.HandleFunc("POST /api/v1/webhooks/gitlab", s.gitlabWebhook)
mux.HandleFunc("POST /api/v1/webhooks/github", s.githubWebhook)
mux.HandleFunc("POST /webhook/github", s.githubWebhookPoC)
```

Оба пути явно исключены из аутентификационной мидлвари (line 2562: `case "/api/v1/health", ..., "/api/v1/webhooks/github", "/api/v1/webhooks/gitlab", ...: return false`) — то есть это неаутентифицированные, интернет-обращённые эндпоинты внутри control-plane, отдельные от сервиса `webhook`.

Реализация `gitlabWebhook` (line 7558+) действительно помечена как deprecated:

```go
func (s *Server) gitlabWebhook(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Deprecation", "true")
	w.Header().Set("Link", `</api/v1/jobs>; rel="successor-version"`)
	if !s.validGitLabToken(r) {
		...
```

— но заголовок `Deprecation: true` не блокирует и не ограничивает вызовы: обработчик выполняется полностью, используя **собственную**, отдельную от `webhook`-репозитория логику проверки токена (`s.validGitLabToken`), не имеющую ни одного из исправлений серии EP-HOOK: нет per-project token resolver (EP-HOOK-001), нет author authorization (EP-HOOK-002), нет replay-защиты (EP-HOOK-003), нет rate-limiting (EP-HOOK-006), нет retry/backoff и таймаутов (EP-HOOK-005/008). Третий путь, `githubWebhookPoC` на `/webhook/github`, судя по имени — забытый proof-of-concept маршрут, отвечающий `http.StatusOK` вместо стандартного `http.StatusAccepted`, тоже полностью боевой.

Дополнительно, `go.mod:11` control-plane тянет `github.com/envplane/webhook v0.1.1` — версию, предшествующую всем найденным в пассе 14 исправлениям пакета `webhook` (см. также [EP-GITOPS-005](../ep-gitops/) о похожей проблеме несинхронизированных версий) — то есть даже там, где control-plane переиспользует код из репозитория `webhook`, это старая, неисправленная версия.

**Сценарий отказа:** атакующий, знающий о существовании GitLab/GitHub-интеграции EnvPlane, просто обращается не к сервису `webhook` (где применены все исправления), а напрямую к control-plane по `/api/v1/webhooks/gitlab` или `/api/v1/webhooks/github` — и получает поведение "до всех фиксов": угадываемый общий статический токен, отсутствие проверки автора комментария, отсутствие replay-защиты, отсутствие rate-limiting. Вся проделанная в рамках EP-HOOK-001..010 работа не даёт защиты, если оба пути остаются одновременно доступны в проде.

## Требуемая реализация

1. Принять и задокументировать явное архитектурное решение: либо (а) полностью удалить `gitlabWebhook`/`githubWebhook`/`githubWebhookPoC` и роуты `/api/v1/webhooks/*`, `/webhook/github` из control-plane, направив весь трафик исключительно через сервис `webhook`; либо (б), если по какой-то причине эти пути должны существовать переходный период, перенести в них все исправления серии EP-HOOK (или сделать их тонкими прокси в сервис `webhook`, а не дублирующей реализацией).
2. Убрать `/webhook/github` (`githubWebhookPoC`) как забытый PoC-маршрут в любом случае — если он был нужен для отладки, ему не место в проде.
3. Обновить зависимость `github.com/envplane/webhook` в `go.mod` control-plane до версии, включающей все фиксы EP-HOOK-серии (зависит от решения [EP-GITOPS-005](../ep-gitops/)/аналогичного тикета о выпуске релизов).
4. Добавить регрессионный тест/CI-проверку, которая фейлится, если в `internal/server` появляется новый `mux.HandleFunc` на путь, содержащий `webhook`, без явного ревью security-владельца.

## Что НЕ входит в этот тикет

Сам процесс выпуска релизов и синхронизации версий (см. отдельный тикет о версионном дрейфе). Здесь фиксируется конкретно наличие дублирующих, необслуживаемых вебхук-приёмников внутри control-plane.

## Критерии приёмки

- В control-plane остаётся ровно один путь обработки внешних GitLab/GitHub вебхуков — либо через актуальную версию пакета `webhook`, либо посредством прокси на выделенный сервис `webhook`; дублирующая небезопасная реализация удалена или доведена до паритета по защите.
- `/webhook/github` (PoC) удалён из production-роутинга.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные; существующие тесты, зависящие от старых маршрутов (если есть), обновлены или удалены осознанно.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/control-plane

Задача: internal/server/server.go регистрирует собственные, полностью рабочие обработчики
вебхуков POST /api/v1/webhooks/gitlab (gitlabWebhook, ~строка 7558), POST /api/v1/webhooks/github
(githubWebhook) и POST /webhook/github (githubWebhookPoC) — все три исключены из
auth-мидлвари (строка ~2562) как публичные, интернет-обращённые эндпоинты. gitlabWebhook помечен
заголовком Deprecation: true, но полностью функционален и использует собственную функцию
validGitLabToken, не содержащую ни одного из исправлений безопасности, сделанных отдельно в
репозитории EnvPlane/webhook (per-project token resolver, author authorization, replay-защита,
rate-limiting, retry/backoff). go.mod тянет github.com/envplane/webhook v0.1.1 — версию, старше
всех этих фиксов. Пока эти маршруты живы и достижимы, атакующий может просто обращаться к
control-plane напрямую вместо сервиса webhook и получать поведение "до всех фиксов".

Нужно: либо полностью удалить gitlabWebhook/githubWebhook/githubWebhookPoC и связанные маршруты
из control-plane, направив весь вебхук-трафик через актуальный, пропатченный сервис webhook, либо
портировать в них все исправления серии EP-HOOK. githubWebhookPoC (/webhook/github) — забытый
PoC-маршрут, должен быть удалён из production-роутинга в любом случае. Обновить зависимость на
webhook в go.mod до версии, включающей фиксы (после того как релиз webhook будет фактически
опубликован — см. связанный тикет о версионном дрейфе).

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
