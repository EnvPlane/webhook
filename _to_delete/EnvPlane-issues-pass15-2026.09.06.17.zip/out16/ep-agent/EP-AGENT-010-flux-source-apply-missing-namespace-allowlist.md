# EP-AGENT-010 — Применение Flux-объектов (Secret/GitRepository/Kustomization) не проверяет допустимый namespace — повторяет уже исправленный класс уязвимости

| Поле | Значение |
|---|---|
| Severity | Critical |
| Направление | security |
| Репозиторий | `agent` |
| Затронутый слой | `agent/flux_source_runtime.go` (`applyFluxSource`, `applyFluxObject`, `isOwnedFluxSourceResource`) |
| Зависит от | Тот же класс бага, что уже был исправлен в `agent/secret_materializer_kubernetes.go:100-102` (`allowedNamespace`-проверка) — здесь она не была перенесена в параллельный write-путь |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `faaf478` |

## Контекст

В `agent/secret_materializer_kubernetes.go` write-путь материализации секретов был исправлен добавлением проверки `allowedNamespace` (согласно предыдущему проходу аудита) — Agent теперь пишет Kubernetes Secret только в namespace, ассоциированный с конкретным проектом.

Новый (или ранее не проверенный) write-путь `agent/flux_source_runtime.go` — применение Flux `GitRepository`-креденшела как Secret, самого `GitRepository` и `Kustomization` — **не содержит эквивалентной проверки**:

```go
func (s *KubernetesNamespaceSource) applyFluxSource(ctx context.Context, command domain.AgentFluxSourceCommand, credential fluxSourceCredential) error {
	secret := map[string]any{"apiVersion": "v1", "kind": "Secret", "metadata": map[string]any{"name": command.CredentialSecretName, "namespace": command.Namespace, ...}, ...}
	if err := s.applyFluxObject(ctx, "/api/v1/namespaces/"+url.PathEscape(command.Namespace)+"/secrets", command.CredentialSecretName, secret); err != nil {
		return err
	}
	repository := map[string]any{..., "metadata": map[string]any{"name": command.GitRepositoryName, "namespace": command.Namespace, ...}, ...}
	...
	kustomization := map[string]any{..., "metadata": map[string]any{"name": command.KustomizationName, "namespace": command.Namespace, ...}, ...}
	return s.applyFluxObject(ctx, ".../namespaces/"+url.PathEscape(command.Namespace)+"/kustomizations", command.KustomizationName, kustomization)
}
```

`command.Namespace` целиком приходит из команды, полученной от control-plane (`reporter.FetchFluxSourceCommand`), и используется без какой-либо проверки на принадлежность ожидаемому/допустимому набору namespace для данного проекта/окружения. Единственная защита в `applyFluxObject` — проверка **владения** уже существующим объектом через `isOwnedFluxSourceResource` (по лейблам и типу) перед перезаписью существующего ресурса — но это защита от перезаписи чужого объекта **в целевом namespace**, а не от записи **в произвольный namespace**. Если объекта ещё не существует (обычный случай для новой команды), проверка вообще не срабатывает (branch `StatusNotFound` просто разрешает `PATCH`/apply).

**Сценарий отказа:** тот же, что уже был устранён для Secret-материализации — если канал доставки команды от control-plane к Agent скомпрометирован (compromised control-plane, MITM при слабой TLS-валидации для `sameCluster`-режима, см. смежный [EP-AGENT-001](../ep-agent/EP-AGENT-001-sameclusters-disables-tls-host-validation.md)), либо просто из-за бага на стороне control-plane, отправляющего неверный `Namespace` в команде, Agent запишет Secret с произвольными кредами и Flux `GitRepository`/`Kustomization` в **любой** namespace целевого кластера клиента — включая namespace других проектов/тенантов в том же кластере (self-hosted/BYOC модель) или системные namespace.

## Требуемая реализация

1. Добавить в `applyFluxSource`/`applyFluxObject` ту же проверку `allowedNamespace`, что уже применяется в `secret_materializer_kubernetes.go` — namespace должен проверяться против namespace, ожидаемого для `command.ProjectID`/окружения, до любого сетевого вызова.
2. Вынести проверку допустимого namespace в общую функцию, разделяемую обоими write-путями (`secret_materializer_kubernetes.go` и `flux_source_runtime.go`), чтобы устранить дублирование логики и предотвратить повторение этого класса бага в будущих write-путях (см. также паттерн "duplicated validation that drifts", неоднократно фиксировавшийся в прошлых проходах).
3. Добавить тест, который передаёт `command.Namespace`, не совпадающий с ожидаемым для проекта, и проверяет отказ до выполнения HTTP-запроса к Kubernetes API.

## Что НЕ входит в этот тикет

Устранение более широкой проблемы TLS-валидации для `sameCluster` (см. EP-AGENT-001) — здесь фиксируется отсутствие namespace-проверки как самостоятельный, достаточный для эксплуатации баг независимо от статуса TLS-проблемы.

## Критерии приёмки

- `applyFluxSource` отклоняет команду, если `command.Namespace` не входит в allowlist, ассоциированный с проектом/окружением, до любого сетевого вызова к Kubernetes API.
- Проверка вынесена в переиспользуемую функцию, используемую обоими write-путями (Secret-материализация и Flux source apply).
- Новый тест подтверждает отказ при недопустимом namespace.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/agent

Задача: agent/flux_source_runtime.go — applyFluxSource применяет Kubernetes Secret (креды Git),
Flux GitRepository и Kustomization в command.Namespace, который целиком приходит из команды от
control-plane, без какой-либо проверки на принадлежность допустимому для данного проекта
namespace. Единственная защита (isOwnedFluxSourceResource в applyFluxObject) проверяет владение
уже существующим объектом в целевом namespace, но не ограничивает, в какой namespace вообще можно
писать, и не срабатывает при создании нового объекта. Это тот же класс уязвимости, который уже
был устранён для Secret-материализации в agent/secret_materializer_kubernetes.go добавлением
allowedNamespace-проверки — здесь она не перенесена.

Нужно: добавить проверку allowedNamespace (по аналогии с secret_materializer_kubernetes.go) перед
любым вызовом applyFluxObject в applyFluxSource — namespace должен проверяться против ожидаемого
для command.ProjectID/окружения набора до выполнения HTTP-запроса. Вынести проверку в общую
переиспользуемую функцию для обоих write-путей, чтобы не дублировать логику. Добавить тест на
отказ при command.Namespace, не совпадающем с ожидаемым.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
