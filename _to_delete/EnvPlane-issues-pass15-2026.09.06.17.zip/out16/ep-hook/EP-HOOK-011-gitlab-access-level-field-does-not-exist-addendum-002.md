# EP-HOOK-011 — Аддендум к EP-HOOK-002: `AuthorAccessLevel` читается из полей, отсутствующих в реальном payload GitLab Note Hook — авторизация комментаторов отказывает всем

| Поле | Значение |
|---|---|
| Severity | High (функциональный отказ — «fail closed», не bypass) |
| Направление | reliability / security |
| Репозиторий | `webhook` |
| Затронутый слой | `internal/scm/event.go:233,243,388-393` (`gitLabAuthorAccessLevel`, поля `gitLabNoteEvent`), `internal/server/server.go:629` (`authorizeCommand`) |
| Зависит от | [EP-HOOK-002](../ep-hook/EP-HOOK-002-no-comment-author-authorization-check.md) — авторизация автора комментария была добавлена, но использует несуществующие в реальном payload поля |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `faf99cd`. Формат payload GitLab Note Hook требует финальной сверки с актуальной документацией GitLab перед реализацией фикса (в среде аудита нет сетевого доступа для повторной проверки на момент этого прохода) |

## Контекст

EP-HOOK-002 требовал добавить проверку прав автора комментария перед выполнением команд из GitLab/GitHub merge request комментариев. Для GitLab реализация выглядит так:

```go
// internal/server/server.go:629
case scm.ProviderGitLab:
    if command.AuthorAccessLevel >= 30 && strings.TrimSpace(command.AuthorID) != "" {
        return nil
    }
    return errors.New("webhook command author is not authorized")
```

```go
// internal/scm/event.go:233,243
type gitLabNoteEvent struct {
    ...
    UserAccessLevel int `json:"user_access_level"`
    ...
    User struct {
        ...
        AccessLevel int `json:"access_level"`
    }
    ...
}

// internal/scm/event.go:388-393
func gitLabAuthorAccessLevel(event gitLabNoteEvent) int {
	if event.User.AccessLevel > 0 {
		return event.User.AccessLevel
	}
	return event.UserAccessLevel
}
```

По данным, собранным в ходе предыдущей проверки этого прохода (сверка со структурой реального GitLab Note Hook payload, задокументированной GitLab), ни верхнеуровневое поле `user_access_level`, ни вложенное `user.access_level` не присутствуют в фактическом теле GitLab Note Hook webhook — GitLab не включает уровень доступа автора комментария непосредственно в payload события. Если это подтверждается, `event.User.AccessLevel` и `event.UserAccessLevel` для реальных запросов всегда равны нулевому значению по умолчанию (Go zero value для отсутствующего JSON-поля), и `gitLabAuthorAccessLevel` всегда возвращает `0`.

**Наблюдаемое следствие:** `command.AuthorAccessLevel >= 30` (порог "Developer" и выше по шкале GitLab: Guest=10, Reporter=20, Developer=30, Maintainer=40, Owner=50) никогда не выполняется → `authorizeCommand` для **любого** GitLab-комментария возвращает `"webhook command author is not authorized"`. Это не bypass (в отличие от типичных находок этого класса) — это полный, безусловный отказ всей функциональности GitLab MR-комментарийных команд, обнаруживаемый только в проде при первой попытке реального пользователя её использовать (сам факт "функция для GitLab работает 0% времени" мог остаться незамеченным, если тестировалось только на GitHub-примерах или синтетических payload с искусственно проставленными полями).

## Требуемая реализация

1. Сверить с актуальной документацией GitLab (Webhook events → Note events), какое поле, если таковое вообще предоставляется в самом payload, отражает уровень доступа автора комментария к проекту. Если GitLab **не** предоставляет эту информацию в самом вебхуке, реализовать её получение отдельным вызовом к GitLab REST/GraphQL API (`GET /projects/:id/members/all/:user_id` или аналог) по `project_id`+`user.id` из события, с использованием токена интеграции.
2. Обновить `gitLabAuthorAccessLevel`/структуру `gitLabNoteEvent`, чтобы источник `AuthorAccessLevel` соответствовал реально доступным данным.
3. Добавить тест на основе реального (или максимально приближенного к документации GitLab) образца payload Note Hook, подтверждающий, что легитимный комментарий от Developer/Maintainer/Owner проходит `authorizeCommand`, а от Guest/Reporter/анонимного — нет.
4. Провести регрессионный прогон (или, при отсутствии тестового GitLab-проекта, ручную проверку с реальным вебхуком) — учитывая, что баг является "fail closed" и, следовательно, легко мог замаскироваться под "функция ещё не запрашивалась" в отсутствие мониторинга отклонённых команд.

## Что НЕ входит в этот тикет

Логика авторизации для GitHub (`AuthorAssociation`) — она не затронута этой находкой и предположительно корректна, так как GitHub Issue Comment webhook payload действительно включает `author_association` непосредственно в событие.

## Критерии приёмки

- `gitLabAuthorAccessLevel` (или её замена) возвращает корректный уровень доступа автора на основе данных, реально присутствующих в GitLab-интеграции (в payload либо через дополнительный API-вызов).
- Тест на реалистичном образце GitLab Note Hook payload подтверждает, что легитимные роли (Developer+) проходят авторизацию, а недостаточные — нет.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/webhook

Задача: аддендум к EP-HOOK-002. internal/scm/event.go:388-393 (gitLabAuthorAccessLevel) читает
уровень доступа автора из event.User.AccessLevel (json: access_level, вложенное поле) и
event.UserAccessLevel (json: user_access_level, верхнеуровневое поле) структуры gitLabNoteEvent.
По предварительной сверке с документацией GitLab, ни одно из этих полей не присутствует в реальном
payload GitLab Note Hook webhook — GitLab не передаёт уровень доступа автора комментария в самом
событии. Если это подтверждается, оба поля для реальных запросов всегда равны 0 (Go zero value),
и internal/server/server.go:629 (command.AuthorAccessLevel >= 30) никогда не проходит — то есть
ВСЕ GitLab MR-комментарийные команды отклоняются как неавторизованные, независимо от реальной
роли автора. Это полный функциональный отказ (fail closed), а не bypass.

Нужно:
1. Сверить с актуальной документацией GitLab (Webhook events → Note events), какие поля реально
   доступны в payload; если уровень доступа туда не включён — реализовать его получение отдельным
   вызовом к GitLab API (GET /projects/:id/members/all/:user_id или аналог) по project_id и user.id
   из события.
2. Обновить gitLabAuthorAccessLevel и связанную структуру под реальный источник данных.
3. Добавить тест на реалистичном образце Note Hook payload, подтверждающий корректную авторизацию
   для Developer+ и отказ для Guest/Reporter/анонимных.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
