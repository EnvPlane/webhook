# EP-GITOPS-010 — `ReleasePlanExecutionInputDigest` хэширует весь изменчивый объект `Environment`, что приводит к ложным отказам привязки плана

| Поле | Значение |
|---|---|
| Severity | High |
| Направление | reliability |
| Репозиторий | `contracts` (используется `runner`) |
| Затронутый слой | `domain/environment_template.go:134-160` (`ReleasePlanExecutionInputDigest`, `ReleasePlanExecutionInputs`), `domain/environment.go:28-68` (`Environment`), потребитель — `runner/internal/runner/runtime.go` (`validateReleasePlanCommand`) |
| Зависит от | Новая находка 15-го прохода — сам механизм привязки (`ExecutionInputDigest`) новый, введён после пассов, зафиксировавших отсутствие такой привязки как проблему (ReleasePlan verified but execution path didn't bind to it) |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `d681e37` |

## Контекст

`ReleasePlanExecutionInputDigest` — новый механизм, призванный связать подписанный `ReleasePlan` с реальными входными данными, которые backend использует при исполнении (устраняет ранее найденный паттерн "подписанный план верифицируется, но исполнение его не использует"):

```go
// domain/environment_template.go:134-160
type ReleasePlanExecutionInputs struct {
	Environment          Environment   `json:"environment"`
	ProjectConfig        ProjectConfig `json:"projectConfig"`
	ChartRef             string        `json:"chartRef,omitempty"`
	ChartVersion         string        `json:"chartVersion,omitempty"`
	ProjectConfigVersion int           `json:"projectConfigVersion,omitempty"`
}

func ReleasePlanExecutionInputDigest(environment Environment, projectConfig ProjectConfig, chartRef, chartVersion string, projectConfigVersion int) (string, error) {
	payload, err := json.Marshal(ReleasePlanExecutionInputs{Environment: environment, ProjectConfig: projectConfig, ChartRef: chartRef, ChartVersion: chartVersion, ProjectConfigVersion: projectConfigVersion})
	...
	sum := sha256.Sum256(payload)
	return "sha256:" + hex.EncodeToString(sum[:]), nil
}
```

Проблема — весь `Environment` целиком (`domain/environment.go:28-68`) участвует в хэшируемом payload. Структура `Environment` содержит поля, которые не влияют на то, что реально деплоится, но регулярно меняются в фоновом режиме независимо от деплоя: `Status`, `UpdatedAt`, `LastActivityAt`, `IdleSince`, `Idle`, `CostEstimate`, `CostEstimateDay`, `Endpoints`, `EndpointPreflight`, `ExpiresAt`, `PinnedUntil` и другие. Runner вычисляет тот же дайджест на своей стороне при получении команды:

```go
// runner/internal/runner/runtime.go
executionInputDigest, err := domain.ReleasePlanExecutionInputDigest(command.Environment, command.ProjectConfig, command.ChartRef, command.ChartVersion, command.ProjectConfigVersion)
if err != nil { ... }
if executionInputDigest != command.ReleasePlan.ExecutionInputDigest {
	return fmt.Errorf("release plan execution input binding mismatch")
}
```

**Сценарий отказа:** между моментом, когда control-plane формирует и подписывает `ReleasePlan` (фиксируя `ExecutionInputDigest` от текущего состояния `Environment`), и моментом, когда runner фактически забирает и исполняет команду, проходит время — обычно секунды-минуты, но потенциально дольше при очереди/ретраях. Если за это время **любое** из перечисленных волатильных полей `Environment` изменится (например, фоновый пересчёт `CostEstimate`, обновление `LastActivityAt` от параллельного heartbeat, изменение `Status` промежуточным переходом, обновление `EndpointPreflight`), `command.Environment`, переданный runner'у, не совпадёт побайтово с тем `Environment`, что был захэширован в момент подписания плана на control-plane — итоговый `executionInputDigest` не совпадёт, и легитимный, ничем не скомпрометированный деплой будет отклонён с "release plan execution input binding mismatch". Это делает деплои непредсказуемо хрупкими под нагрузкой или при любой параллельной активности с тем же окружением — ровно тот тип бага, который трудно воспроизвести детерминированно и который выглядит как "рандомные" сбои в проде.

## Требуемая реализация

1. Определить явный, минимальный набор полей `Environment`, которые действительно влияют на результат деплоя (namespace, chart-конфигурация, `Services`/`Components`/`Overrides`, `GitOps`, `Charts`, `Infrastructure`, `Base`, `Source` и т.п.), и хэшировать только их — например, через отдельную "deployment-relevant" проекцию `Environment`, а не структуру целиком.
2. Явно исключить поля, помеченные как заведомо волатильные и не влияющие на деплой (`Status`, `UpdatedAt`, `LastActivityAt`, `IdleSince`, `Idle`, `CostEstimate*`, `Endpoints`, `EndpointPreflight`, `ExpiresAt`, `PinnedUntil`) — задокументировать явно в коде (комментарием), почему каждое поле включено или исключено, чтобы будущее добавление нового волатильного поля в `Environment` не тихо расширяло хэшируемую поверхность.
3. Добавить тест, который берёт валидный `ReleasePlan`, затем мутирует заведомо волатильное поле `Environment` (например, `LastActivityAt`) и подтверждает, что дайджест **не** меняется; отдельный тест — что мутация deployment-relevant поля (например, `Charts`) дайджест меняет.

## Что НЕ входит в этот тикет

Полный пересмотр протокола `ReleasePlan`/подписи — только сужение состава полей, участвующих в `ExecutionInputDigest`.

## Критерии приёмки

- `ReleasePlanExecutionInputDigest` вычисляется от явно ограниченной, задокументированной проекции `Environment`, исключающей волатильные операционные поля.
- Тест на неизменность дайджеста при мутации волатильного поля и на изменение при мутации deployment-relevant поля — оба проходят.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные в `contracts` и в `runner` (после обновления зависимости).

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/contracts (потребитель: EnvPlane/runner)

Задача: domain/environment_template.go:134-160, функция ReleasePlanExecutionInputDigest хэширует
весь объект Environment целиком (domain/environment.go:28-68) как часть привязки исполняемых
входных данных к подписанному ReleasePlan. Environment содержит волатильные операционные поля
(Status, UpdatedAt, LastActivityAt, IdleSince, Idle, CostEstimate, CostEstimateDay, Endpoints,
EndpointPreflight, ExpiresAt, PinnedUntil), которые регулярно меняются в фоне независимо от того,
что реально деплоится. Runner (runner/internal/runner/runtime.go, validateReleasePlanCommand)
пересчитывает тот же дайджест на своей стороне при получении команды и отклоняет план при
несовпадении ("release plan execution input binding mismatch"). Если любое волатильное поле
Environment изменится между подписанием плана на control-plane и его исполнением на runner
(например, из-за параллельного heartbeat или фонового пересчёта стоимости), легитимный деплой
будет ошибочно отклонён.

Нужно: выделить явную, минимальную "deployment-relevant" проекцию Environment (namespace,
chart-конфигурация, Services/Components/Overrides, GitOps, Charts, Infrastructure, Base, Source и
т.п.), хэшировать только её, явно исключив волатильные операционные поля, с комментарием,
объясняющим, почему каждое поле включено или исключено. Добавить тесты: мутация волатильного поля
не меняет дайджест; мутация deployment-relevant поля дайджест меняет. Обновить runner под новую
сигнатуру/поведение, если потребуется.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./... в contracts и в runner
```
