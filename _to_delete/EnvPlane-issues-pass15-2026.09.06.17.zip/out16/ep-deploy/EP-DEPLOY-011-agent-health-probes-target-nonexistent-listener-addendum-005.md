# EP-DEPLOY-011 — Аддендум/регрессия к EP-DEPLOY-005: TCP-пробы Agent включены по умолчанию и нацелены на порт, который образ Agent не слушает

| Поле | Значение |
|---|---|
| Severity | Critical |
| Направление | reliability |
| Репозиторий | `deploy` |
| Затронутый слой | `deploy/deploy/helm/envplane-agent/values.yaml:53-70` (`health.enabled: true`, комментарий строк 53-56), `deploy/deploy/helm/envplane-agent/templates/deployment.yaml:206-220` (`livenessProbe`/`readinessProbe`) |
| Зависит от | [EP-DEPLOY-005](../ep-deploy/EP-DEPLOY-005-agent-missing-liveness-readiness-probes.md) — пробы были добавлены по итогам этого тикета, но дефолтное включение вводит новую критическую регрессию |
| Статус верификации | Подтверждено прямым чтением кода на устройстве пользователя 6 сентября 2026, коммит `9645cf4`. Дополнительно подтверждено отсутствие HTTP/TCP-листенера в самом бинаре Agent (репозиторий `agent`, коммит `faaf478`) — `grep` по всему модулю на `ListenAndServe`/открытие серверного порта не находит ничего в неисходном коде |

## Контекст

EP-DEPLOY-005 требовал добавить liveness/readiness пробы для Agent (их отсутствие само по себе было находкой). Пробы добавлены:

```yaml
# deploy/deploy/helm/envplane-agent/templates/deployment.yaml:206-220
{{- if .Values.health.enabled }}
livenessProbe:
  tcpSocket:
    port: {{ .Values.health.port }}
  ...
readinessProbe:
  tcpSocket:
    port: {{ .Values.health.port }}
  ...
{{- end }}
```

Однако сам чарт честно документирует проблему прямо в комментарии над дефолтным значением — и затем немедленно противоречит собственной рекомендации:

```yaml
# deploy/deploy/helm/envplane-agent/values.yaml:53-56
# The Agent image currently has no HTTP health endpoint. These TCP probes are
# enabled by default and target the port reserved for the Agent health listener.
# The listener must be added to the Agent image before deploying this default
# in a cluster; until then, set health.enabled=false explicitly.
health:
  enabled: true
  port: 8080
```

Комментарий прямым текстом говорит "until then, set health.enabled=false explicitly" — но `enabled: true` остаётся значением по умолчанию, то есть рекомендация из комментария не применена к самому дефолту. Проверка репозитория `agent` (все `.go`-файлы, кроме тестов) не находит ни одного вызова `http.ListenAndServe`/аналога — Agent является чисто исходящим (outbound-polling) клиентом (heartbeat, fetch команд) и не открывает вообще никакого сетевого порта, ни HTTP, ни голого TCP.

**Сценарий отказа:** любой новый деплой `envplane-agent` с дефолтными values (без явного `--set health.enabled=false`) получает под с `livenessProbe`/`readinessProbe`, проверяющими TCP-соединение на порт 8080 — соединение никогда не устанавливается, поскольку ничего не слушает этот порт. `readinessProbe` навсегда держит под в состоянии `NotReady` (если Agent когда-либо будет поставлен за Service — сейчас, возможно, не критично, но это a priori ломает штатное поведение оркестрации); `livenessProbe`, проваливающийся `failureThreshold: 3` раз подряд, приводит к перманентному **restart loop** пода kubelet'ом — то есть полностью работоспособный, корректно выполняющий свою функцию процесс Agent убивается и перезапускается по кругу исключительно из-за probe-конфигурации, никак не связанной с его реальным состоянием. Это блокирующий, "из коробки" ломающий продукт баг для любого нового или переустановленного Agent на дефолтных values.

## Требуемая реализация

1. Немедленно (короткий путь): изменить дефолт `health.enabled` на `false` в `values.yaml`, чтобы чарт соответствовал собственному документирующему комментарию, до тех пор, пока в образ Agent не добавлен реальный health-листенер.
2. Полноценное решение: добавить в бинарь `agent` (репозиторий `agent`) простой HTTP или TCP health-listener (например, `/healthz` на выделенном порту, не пересекающемся с исходящими соединениями), отражающий реальное состояние процесса (например, "последний successful heartbeat не старше N секунд назад"), и только после этого включать `health.enabled: true` по умолчанию.
3. Добавить CI/lint-проверку (`ct lint`/`helm template`-based), которая фейлится, если `values.yaml` какого-либо чарта включает `livenessProbe`/`readinessProbe` (`tcpSocket`/`httpGet`) с портом, для которого нет соответствующего `containerPort`, объявленного в том же `deployment.yaml` (что уже покрыло бы этот класс рассинхронизации автоматически).

## Что НЕ входит в этот тикет

Реализация самого health-эндпоинта в коде `agent` — это отдельная задача в репозитории `agent`; здесь фиксируется сам факт опасного дефолта в чарте `deploy` и предлагается немедленный безопасный дефолт до её выполнения.

## Критерии приёмки

- Дефолтное значение `health.enabled` в `values.yaml` соответствует фактическому наличию health-листенера в образе Agent (`false`, пока листенера нет; переключается на `true` только вместе с PR, добавляющим листенер в `agent`).
- `helm template deploy/deploy/helm/envplane-agent` с дефолтными values не рендерит `livenessProbe`/`readinessProbe`, нацеленные на несуществующий порт.
- Добавлена (или расширена существующая) lint-проверка, сверяющая порты проб с объявленными `containerPort`.
- `helm lint`/`helm template --validate` для `envplane-agent` проходят.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/deploy

Задача: аддендум/регрессия к EP-DEPLOY-005. deploy/deploy/helm/envplane-agent/values.yaml:53-59
устанавливает health.enabled: true по умолчанию, при этом собственный комментарий чарта (строки
53-56) прямо говорит: "The Agent image currently has no HTTP health endpoint... until then, set
health.enabled=false explicitly" — то есть значение по умолчанию противоречит собственной
задокументированной рекомендации. Проверка репозитория agent подтверждает: бинарь не открывает
никакого сетевого листенера (нет http.ListenAndServe и аналогов) — это чисто исходящий
polling-клиент. deployment.yaml:206-220 рендерит livenessProbe и readinessProbe с tcpSocket на
порт health.port (8080) при health.enabled=true. Результат: любой новый под Agent на дефолтных
values уходит в перманентный restart loop от liveness-фейлов и никогда не становится Ready,
несмотря на то что процесс полностью работоспособен.

Нужно:
1. Немедленно изменить дефолт health.enabled на false в values.yaml, чтобы соответствовать
   собственному комментарию чарта, до появления реального health-листенера в образе agent.
2. (Если задача расширяется на репозиторий agent) добавить простой HTTP-листенер /healthz,
   отражающий реальное состояние процесса, и только тогда переключить дефолт обратно на true.
3. Добавить lint-проверку (ct lint/helm template based), сверяющую, что порт любого
   livenessProbe/readinessProbe совпадает с объявленным containerPort в том же deployment.yaml.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: helm lint deploy/deploy/helm/envplane-agent, helm template --validate deploy/deploy/helm/envplane-agent
```
