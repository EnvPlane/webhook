# EP-UI-049 — Аддендум к EP-UI-040: `ProjectsListClient.tsx` по-прежнему рендерит сырые `href` без `safeHref` (третье подряд подтверждение)

| Поле | Значение |
|---|---|
| Severity | Medium |
| Направление | security |
| Репозиторий | `frontend` |
| Затронутый слой | `components/projects/ProjectsListClient.tsx:36,41` |
| Зависит от | [EP-UI-040](../ep-ui/EP-UI-040-href-schema-validation-xss.md) — `safeHref` внедрён и используется в `EnvironmentDetailsClient.tsx`/`QuotaErrorNotice.tsx`, но этот файл остаётся неохваченным уже второй проход подряд |
| Статус верификации | Подтверждено независимым агентом верификации 7 сентября 2026, коммит `e36317c` |

## Контекст

`safeHref` (`components/api/safeHref.ts`) — утилита санитизации URL, введённая по EP-UI-040 для устранения XSS-риска через непроверенные `href`, — используется в `EnvironmentDetailsClient.tsx` (`previewUrl`, `scmChangeUrl`) и `QuotaErrorNotice.tsx` (`upgrade_url`). `ProjectsListClient.tsx` остаётся неохваченным:

```tsx
// components/projects/ProjectsListClient.tsx:36
render: (project: Project) => project.repository ? <a className="row-link" href={project.repository} rel="noreferrer" target="_blank" ...>

// components/projects/ProjectsListClient.tsx:41
render: (project: Project) => project.gitOpsRepo ? <a className="row-link" href={project.gitOpsRepo} rel="noreferrer" target="_blank" ...>
```

`project.repository` и `project.gitOpsRepo` подставляются в `href` напрямую. Это уже второй проход аудита подряд, отмечающий именно этот файл как остаточный пробел внедрения `safeHref` — то есть исправление применяется точечно по мере обнаружения конкретных мест, а не по итогам полного грепа всех `href={...}` в кодовой базе.

**Сценарий отказа:** если поле `repository`/`gitOpsRepo` в данных проекта (заполняется через API/пользовательский ввод при создании проекта) содержит `javascript:`-URI или иной небезопасный протокол, ссылка в таблице проектов рендерится без проверки — потенциальный stored-XSS вектор через ссылку, видимую всем пользователям с доступом к списку проектов.

## Требуемая реализация

1. Применить `safeHref` к обоим полям в `ProjectsListClient.tsx`.
2. Провести один системный проход по всему `frontend`-кодбейсу (`grep -rn "href={" components/ app/`), чтобы найти все оставшиеся места с непроверенным `href` за один раз, а не находить их по одному в каждом следующем аудите — приложить полный список найденных мест к PR, даже если чинится только `ProjectsListClient.tsx` в рамках этого тикета.
3. Рассмотреть возможность обеспечить это на уровне типов/lint-правила — например, кастомное ESLint-правило (по аналогии с уже добавленным `envplane/no-identical-expressions`, см. EP-UI-048), запрещающее `href={<переменная>}` без обёртки в `safeHref`/`safeExternalHref` там, где значение не является статической строкой.

## Что НЕ входит в этот тикет

Полная миграция всех найденных по итогам грепа мест — по объёму тикета обязательна только правка `ProjectsListClient.tsx`; остальные найденные места (если есть) фиксируются отдельными тикетами по результатам грепа.

## Критерии приёмки

- `ProjectsListClient.tsx:36,41` используют `safeHref`.
- К PR приложен полный список остальных мест с непроверенным `href` в кодовой базе (из грепа), даже если они не исправляются в рамках этого тикета.
- `npm run lint`, `npm run build` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/frontend

Задача: аддендум к EP-UI-040, третье подряд подтверждение одного и того же пробела.
components/projects/ProjectsListClient.tsx:36,41 рендерит project.repository и project.gitOpsRepo
напрямую в href без safeHref (components/api/safeHref.ts), в отличие от EnvironmentDetailsClient.tsx
и QuotaErrorNotice.tsx, где safeHref уже применяется. Потенциальный stored-XSS вектор через
javascript:-URI в поле repository/gitOpsRepo.

Нужно: применить safeHref к обоим местам в ProjectsListClient.tsx. Дополнительно выполнить
grep -rn "href={" components/ app/ по всему кодбейсу frontend, чтобы найти остальные непроверенные
href за один системный проход (а не находить по одному в каждом следующем аудите), и приложить
список найденного к PR. Рассмотреть кастомное ESLint-правило, запрещающее href={<переменная>} без
обёртки в safeHref там, где значение не статическая строка.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: npm run lint, npm run build
```
