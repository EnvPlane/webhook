# EP-DEPLOY-012 — Аддендум к EP-DEPLOY-011: lint-проверка портов проб покрывает только чарт `envplane-agent` и только `tcpSocket`

| Поле | Значение |
|---|---|
| Severity | Medium |
| Направление | reliability / process |
| Репозиторий | `deploy` |
| Затронутый слой | `scripts/check-probe-container-ports.sh`, `.github/workflows/ci.yaml` (шаг "Check probe ports"), `deploy/helm/envplane-control-plane/templates/deployment.yaml:653-670` (`httpGet`, именованный порт `http`), `deploy/helm/envplane-runner/templates/deployment.yaml:229-251` (`httpGet`, `.Values.service.targetPort`) |
| Зависит от | [EP-DEPLOY-011](../ep-deploy/EP-DEPLOY-011-agent-health-probes-target-nonexistent-listener-addendum-005.md) — сама находка исправлена корректно; guard, добавленный вместе с фиксом, покрывает уже произошедший случай, но не весь класс бага |
| Статус верификации | Подтверждено независимым агентом верификации 7 сентября 2026, коммит `3dba5f7` |

## Контекст

Вместе с EP-DEPLOY-011 добавлен `scripts/check-probe-container-ports.sh` — скрипт, рендерящий чарт через `helm template` и сверяющий через `yq`, что порты `livenessProbe`/`readinessProbe` (`tcpSocket.port`) совпадают с объявленными `containerPort`. В CI он подключён только для одного чарта:

```yaml
- name: Check probe ports
  run: ./scripts/check-probe-container-ports.sh deploy/helm/envplane-agent
```

Это оставляет непокрытыми:

1. **Остальные чарты** — `envplane-control-plane`, `envplane-runner` не проверяются этим guard'ом вовсе.
2. **Тип пробы `httpGet`** — сам скрипт извлекает только `tcpSocket.port`, но не `httpGet.port`. При этом именно `httpGet` используется в реальных чартах: `envplane-control-plane/templates/deployment.yaml:653-670` (`port: http`, именованный порт контейнера) и `envplane-runner/templates/deployment.yaml:229-251` (`port: {{ .Values.service.targetPort }}`).

**Сценарий отказа:** если в будущем в `envplane-control-plane` или `envplane-runner` появится рассинхронизация между именем/номером порта `httpGet`-пробы и реальным `containerPort` (например, при переименовании порта в одном месте, но не в другом) — ровно тот класс бага, из-за которого возник EP-DEPLOY-011 (только там это было `tcpSocket` на несуществующий порт агента), — новый guard этого не заметит, поскольку не проверяет ни эти чарты, ни этот тип пробы.

## Требуемая реализация

1. Расширить `check-probe-container-ports.sh`, чтобы он также извлекал и сверял `httpGet.port` (учитывая, что порт там может быть указан и числом, и именем — в последнем случае сверять с `name` в списке `ports` контейнера, а не с числовым значением напрямую).
2. Подключить проверку в CI для всех чартов с подами приложений — как минимум `envplane-control-plane` и `envplane-runner`, в дополнение к `envplane-agent`.
3. Рассмотреть более общее решение — единый шаг CI, автоматически находящий все чарты с `templates/deployment.yaml` в репозитории и прогоняющий проверку по каждому, а не явный список путей, который придётся вручную поддерживать при добавлении новых чартов.

## Что НЕ входит в этот тикет

Проверка портов для `livenessProbe`/`readinessProbe`/`startupProbe` в чартах сторонних зависимостей (subchart'ы) — только чарты, поддерживаемые непосредственно в этом репозитории.

## Критерии приёмки

- `check-probe-container-ports.sh` проверяет как `tcpSocket.port`, так и `httpGet.port` (включая именованные порты).
- CI прогоняет эту проверку как минимум для `envplane-agent`, `envplane-control-plane`, `envplane-runner`.
- Намеренно внесённая рассинхронизация порта пробы в любом из этих трёх чартов ловится проверкой (проверить вручную/тестовым сценарием перед мержем).

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/deploy

Задача: аддендум к EP-DEPLOY-011. scripts/check-probe-container-ports.sh подключён в CI только
для deploy/helm/envplane-agent и проверяет только livenessProbe/readinessProbe.tcpSocket.port —
не проверяет httpGet.port и не запускается для envplane-control-plane/envplane-runner, где реально
используется httpGet (deploy/helm/envplane-control-plane/templates/deployment.yaml:653-670,
deploy/helm/envplane-runner/templates/deployment.yaml:229-251). Рассинхронизация имени/номера
httpGet-порта пробы и реального containerPort в этих чартах не будет обнаружена текущим guard'ом
— тот же класс бага, что вызвал EP-DEPLOY-011, но для другого типа пробы и других чартов.

Нужно: расширить check-probe-container-ports.sh для проверки httpGet.port (включая именованные
порты — сверка по имени порта контейнера, если значение не числовое), подключить проверку в CI как
минимум для envplane-agent, envplane-control-plane, envplane-runner. Рассмотреть автоматическое
обнаружение всех чартов с templates/deployment.yaml вместо явного списка путей.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: helm lint и helm template --validate для всех трёх чартов; ручная проверка, что
намеренная рассинхронизация порта ловится проверкой
```
