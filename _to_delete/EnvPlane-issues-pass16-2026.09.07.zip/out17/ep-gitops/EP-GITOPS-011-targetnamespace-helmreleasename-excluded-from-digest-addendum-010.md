# EP-GITOPS-011 — Аддендум к EP-GITOPS-010: top-level `Environment.TargetNamespace`/`HelmReleaseName` тоже исключены из execution-дайджеста — требуется подтвердить, не используются ли они control-plane для реального таргетинга деплоя

| Поле | Значение |
|---|---|
| Severity | Medium (потенциально High — зависит от использования в control-plane, вне зоны видимости этого аудита) |
| Направление | security / reliability |
| Репозиторий | `contracts` (потребители: `control-plane`, `runner`) |
| Затронутый слой | `contracts/domain/environment_template.go` (`ReleasePlanDeploymentEnvironment`), `contracts/domain/environment.go:40-41` (`Environment.TargetNamespace`, `Environment.HelmReleaseName`) |
| Зависит от | [EP-GITOPS-010](../ep-gitops/EP-GITOPS-010-executioninputdigest-hashes-volatile-environment.md) — сама находка исправлена корректно; этот тикет фиксирует необходимость проверить, не задел ли новый дизайн проекции и deployment-relevant поля |
| Статус верификации | Обнаружено независимым агентом верификации 7 сентября 2026, коммит `8c2fdbf`, требует дополнительной проверки в `control-plane` (вне зоны доступа агента, аудировавшего только `contracts`/`gitops`/`bootstrap`) |

## Контекст

EP-GITOPS-010 исправлен: `ReleasePlanExecutionInputDigest` теперь хэширует не `Environment` целиком, а специально выделенную проекцию `ReleasePlanDeploymentEnvironment`, корректно исключающую все 11 перечисленных в исходном тикете волатильных полей (`Status`, `UpdatedAt`, `LastActivityAt`, `IdleSince`, `Idle`, `CostEstimate`, `CostEstimateDay`, `Endpoints`, `EndpointPreflight`, `ExpiresAt`, `PinnedUntil`).

При этом проекция также не включает два **top-level** поля `Environment`, не упомянутых в исходном тикете:

```go
// contracts/domain/environment.go:40-41
TargetNamespace             string                     `json:"targetNamespace,omitempty"`
HelmReleaseName             string                     `json:"helmReleaseName,omitempty"`
```

Это отдельные от `GitOps.TargetNamespace` (вложенного в `GitOpsTarget`, который **остался** в проекции и используется рендерером) поля. Новый тест `TestReleasePlanExecutionInputDigestIgnoresVolatileEnvironmentFields` явно мутирует именно их (значениями вида `"resolved-ns-a"`/`"resolved-release-a"`) и ожидает, что дайджест не меняется — то есть авторы фикса сознательно трактуют их как «наблюдаемые/вычисляемые» поля, аналогичные `Status`, а не как deployment-relevant вход.

Проверка по `gitops`/`bootstrap` (единственным бэкендам исполнения, доступным для аудита этого прохода) не находит использования этих top-level полей — рендерер использует только `Environment.GitOps.TargetNamespace`, который в проекции есть. **Однако `control-plane` (второй потребитель `contracts`, не входивший в зону этого конкретного аудита) не проверялся на предмет того, использует ли он `Environment.TargetNamespace`/`HelmReleaseName` для реального разрешения имени namespace/release при деплое** — например, при разрешении коллизий namespace между окружениями или как часть логики HelmDirect-бэкенда в runner.

**Потенциальный сценарий отказа (требует подтверждения):** если хотя бы один реальный path исполнения адресует деплой через `Environment.TargetNamespace`/`HelmReleaseName` (а не через `Namespace`/`GitOps.TargetNamespace`, которые в дайджест входят), то фоновое или злонамеренное изменение этих значений между подписанием плана и его исполнением runner'ом не будет обнаружено верификацией дайджеста — воспроизводя, для namespace/release-таргетинга, ровно тот класс проблемы, который EP-GITOPS-010 должен был закрыть для статусных полей.

## Требуемая реализация

1. Провести целевую проверку в репозитории `control-plane`: grep/чтение всех мест использования `Environment.TargetNamespace` и `Environment.HelmReleaseName` — используются ли они как фактический вход для формирования namespace/release имени при реальном деплое, или это чисто отображаемые/устаревшие поля.
2. Если подтверждается реальное использование для таргетинга деплоя — включить оба поля в `ReleasePlanDeploymentEnvironment` и обновить тесты соответственно (перенести их мутацию из теста "игнорируется" в тест "включается").
3. Если подтверждается, что поля не используются для деплоя (действительно наблюдаемые/legacy) — явно задокументировать это решение комментарием в `ReleasePlanDeploymentEnvironment`, аналогично остальным исключённым полям, чтобы будущий читатель не заново поднимал этот вопрос без ответа.

## Что НЕ входит в этот тикет

Полный редизайн полей `Environment` — только подтверждение корректности состава `ReleasePlanDeploymentEnvironment` относительно этих двух конкретных полей.

## Критерии приёмки

- Результат проверки в `control-plane` задокументирован (комментарием в коде и/или в этом тикете при закрытии).
- Если поля деплой-релевантны — они добавлены в проекцию, тесты обновлены.
- Если поля не деплой-релевантны — это явно закомментировано в определении `ReleasePlanDeploymentEnvironment`.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные в `contracts` и (если менялся) в `control-plane`.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/contracts (требует также проверки в EnvPlane/control-plane)

Задача: аддендум к EP-GITOPS-010. contracts/domain/environment_template.go — новая проекция
ReleasePlanDeploymentEnvironment (введённая фиксом EP-GITOPS-010) не включает top-level поля
Environment.TargetNamespace и Environment.HelmReleaseName (contracts/domain/environment.go:40-41),
отдельные от Environment.GitOps.TargetNamespace, который в проекции есть и используется рендерером
gitops. Тест TestReleasePlanExecutionInputDigestIgnoresVolatileEnvironmentFields трактует их как
волатильные и ожидает, что их мутация не меняет дайджест — но по gitops/bootstrap эти конкретные
поля нигде не используются, а control-plane (второй потребитель) не проверялся в рамках прошлого
аудита.

Нужно: проверить в репозитории control-plane все места использования Environment.TargetNamespace и
Environment.HelmReleaseName — используются ли они как реальный вход для формирования
namespace/release-имени при деплое. Если да — включить оба поля в ReleasePlanDeploymentEnvironment
и перенести их в тест "digest включает deployment-relevant поля". Если нет — явно задокументировать
комментарием в определении структуры, что это осознанное решение, а не пропуск.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./... в contracts и (если менялся) в control-plane
```
