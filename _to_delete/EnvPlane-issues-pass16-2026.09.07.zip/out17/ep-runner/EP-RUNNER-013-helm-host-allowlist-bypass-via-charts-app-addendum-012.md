# EP-RUNNER-013 — Аддендум к EP-RUNNER-012: allowlist хостов Helm-чарта обходится через legacy-поле `Environment.Charts.App`

| Поле | Значение |
|---|---|
| Severity | High |
| Направление | security (SSRF / supply chain) |
| Репозиторий | `runner` |
| Затронутый слой | `internal/runner/runtime.go:1057-1077` (проверка), `:1126-1134` (`runnerHelmChartRef`), `:1344-1358` (`runnerHelmChartHostAllowed`), `internal/orchestrator/orchestrator.go:661-673` (`HelmDirectBackend.chartRef`) |
| Зависит от | [EP-RUNNER-012](../ep-runner/EP-RUNNER-012-helm-chart-host-allowlist-not-wired-real-deploy.md) — allowlist подключён к реальному пути деплоя, но не ко всем каналам, которыми этот же путь получает chart-ссылку |
| Статус верификации | Подтверждено прямым чтением кода независимым агентом верификации 7 сентября 2026, коммит `69e4bb2`. Статус EP-RUNNER-012: **ЧАСТИЧНО ИСПРАВЛЕНО** |

## Контекст

EP-RUNNER-012 успешно подключил `runnerHelmChartHostAllowed` к реальному пути `create`/`recreate` перед `backend.Apply(...)` (`runtime.go:1057-1077`). Однако chart-ссылка, которую эта проверка получает, вычисляется отдельной функцией `runnerHelmChartRef`:

```go
// internal/runner/runtime.go:1126-1134
func runnerHelmChartRef(command domain.RunnerCommand, projectConfig domain.ProjectConfig) string {
	if chartRef := strings.TrimSpace(command.ChartRef); chartRef != "" { return chartRef }
	deployment, _ := projectConfig.Config["deployment"].(map[string]any)
	helmDirect, _ := deployment["helmDirect"].(map[string]any)
	chartRef, _ := helmDirect["chartRef"].(string)
	return strings.TrimSpace(chartRef)
}
```

— которая проверяет только `command.ChartRef` и `projectConfig.Config.deployment.helmDirect.chartRef`. Но фактический chart-путь, реально используемый при `helm upgrade --install` внутри `HelmDirectBackend.Apply` → `chartRef()` (`internal/orchestrator/orchestrator.go:661-673`), имеет дополнительный legacy-фолбэк:

```go
func (b *HelmDirectBackend) chartRef(environment domain.Environment, config helmDirectConfig) string {
	if ref := strings.TrimSpace(config.chartRef); ref != "" { return ref }
	ref := strings.TrimSpace(environment.Charts.App)
	if ref != "" { return ref }
	if strings.TrimSpace(environment.GitOps.Path) != "" { return strings.TrimSpace(environment.GitOps.Path) }
	return "latest"
}
```

`environment.Charts.App` активно используется как источник chart-ссылки (в том числе в существующих тестах оркестратора), но `runnerHelmChartRef` о нём не знает.

**Сценарий отказа:** если в конфигурации проекта отсутствует `deployment.helmDirect.chartRef` (пусто/не задано), а `Environment.Charts.App` указывает на непроверенный хост (например, `oci://evil.example/charts/app`): `runnerHelmChartRef` вернёт `""`; `runnerHelmChartHostAllowed("", allowedHosts)` трактует пустую строку как «локальный алиас репозитория» и возвращает `true` (проверка пройдена); но `backend.Apply` реально выполнит `helm upgrade --install` с `ChartRef = environment.Charts.App`, хостом, который ни разу не сверялся с allowlist. Allowlist защищает только «новый» канал (`helmDirect.chartRef`), «legacy»-канал остаётся полностью открытым для того же класса SSRF/supply-chain атаки, который EP-RUNNER-005/012 и должны были закрыть.

## Требуемая реализация

1. Переиспользовать саму функцию `chartRef()` из `internal/orchestrator` (либо вынести её в общий пакет) вместо параллельной, менее полной `runnerHelmChartRef` — так, чтобы значение, проверяемое allowlist'ом, и значение, реально передаваемое в `helm`, вычислялись одним и тем же кодом, а не двумя похожими, но разошедшимися реализациями (тот же класс «правило продублировано и разошлось», неоднократно фиксировавшийся в этом проекте).
2. Явно решить (и задокументировать), остаётся ли `Environment.GitOps.Path` в этом списке фолбэков сетевым вектором — если это всегда локальный путь в git-репозитории, а не сетевая ссылка, явно отфильтровать его из логики allowlist-проверки как не подпадающий под неё; если может быть сетевым — тоже включить в проверку.
3. Добавить интеграционный тест: `create`/`recreate` с пустым `helmDirect.chartRef`, но `Environment.Charts.App`, указывающим на неаллоулистенный хост — должен быть отклонён до вызова `backend.Apply`.
4. Дополнительно (меньший приоритет, отмечено при верификации EP-RUNNER-011): добавить тест на «чужой» `kind` — ресурс с Kind вне `cfg.releasePlanAllowedKinds()` — механизм `ReleasePlanAllowedKinds`/`ENVPLANE_RELEASE_PLAN_ALLOWED_KINDS` сейчас не покрыт ни одним тестом, хотя EP-RUNNER-011 требовал тест и на namespace, и на kind.

## Что НЕ входит в этот тикет

Полный редизайн модели конфигурации chart-ссылки (`ChartRef` vs `helmDirect.chartRef` vs `Charts.App` vs `GitOps.Path`) — тикет фиксирует только необходимость единого источника истины между allowlist-проверкой и реальным использованием.

## Критерии приёмки

- Значение, проверяемое `runnerHelmChartHostAllowed`, вычисляется той же функцией (или обёрткой над ней), что и значение, реально передаваемое в `helm upgrade --install`.
- Новый тест: `create` с пустым `helmDirect.chartRef` и `Charts.App` на неаллоулистенном хосте отклоняется до `backend.Apply`.
- Добавлен тест на «чужой» kind вне `cfg.releasePlanAllowedKinds()` (довершает требование EP-RUNNER-011).
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/runner

Задача: аддендум к EP-RUNNER-012. internal/runner/runtime.go:1126-1134 (runnerHelmChartRef) —
функция, значение которой проверяется allowlist'ом хостов (runnerHelmChartHostAllowed) перед
реальным деплоем — учитывает только command.ChartRef и projectConfig.Config.deployment.helmDirect.chartRef.
Но фактическое значение chart-ссылки, реально используемое при helm upgrade --install
(internal/orchestrator/orchestrator.go:661-673, HelmDirectBackend.chartRef), имеет дополнительный
фолбэк на environment.Charts.App (и затем environment.GitOps.Path). Если helmDirect.chartRef пуст,
а Charts.App указывает на непроверенный хост, runnerHelmChartRef вернёт пустую строку,
runnerHelmChartHostAllowed трактует пустую строку как "локальный алиас" и пропускает проверку, но
backend.Apply реально задеплоит chart с Charts.App — хостом, никогда не сверенным с allowlist.

Нужно: унифицировать вычисление chart-ссылки — либо runtime.go должен вызывать ту же функцию
chartRef(), что и HelmDirectBackend, либо она должна быть вынесена в общий пакет и использоваться
в обоих местах. Явно решить и задокументировать трактовку environment.GitOps.Path (сетевой ли это
вектор). Добавить интеграционный тест: create с пустым helmDirect.chartRef и Charts.App на
неаллоулистенном хосте отклоняется до вызова backend.Apply. Дополнительно добавить тест на "чужой"
kind вне cfg.releasePlanAllowedKinds() (довершает требование EP-RUNNER-011, которое пока покрыто
только для namespace).

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
