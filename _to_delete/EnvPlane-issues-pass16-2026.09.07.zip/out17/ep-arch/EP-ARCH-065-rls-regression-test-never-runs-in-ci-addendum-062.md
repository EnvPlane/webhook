# EP-ARCH-065 — Аддендум к EP-ARCH-062: регрессионный RLS-тест никогда не выполняется в CI, guard-regex не покрывает все SQL-методы

| Поле | Значение |
|---|---|
| Severity | High |
| Направление | reliability / process |
| Репозиторий | `control-plane` |
| Затронутый слой | `internal/store/sql_store_integration_test.go:835-882` (тест `TestSQLListTenantIDsUsesPlatformRLSContext`), `.github/workflows/ci.yaml` (условие запуска integration-тестов), `scripts/check-tenant-scope.sh:19-20` (regex-guard), `internal/store/identity_store.go:38,47` |
| Зависит от | [EP-ARCH-062](../ep-arch/EP-ARCH-062-listtenantids-rls-silent-empty-result.md) — сам баг исправлен корректно, но два из трёх требуемых защитных механизма не работают так, как задумано |
| Статус верификации | Подтверждено прямым чтением кода и CI-конфигурации независимым агентом верификации 7 сентября 2026, коммит `ad0bf6d` |

## Контекст

EP-ARCH-062 исправлен по существу — все три `ListTenantIDs()` теперь используют `platformQueryRows`. Однако из трёх требуемых защитных механизмов (сам фикс, CI regex-guard, интеграционный тест) корректно работает только первый.

**1. Интеграционный тест не выполняется на практике.** `internal/store/sql_store_integration_test.go:835-882` содержит логику само-скипа:

```go
if isSuperuser {
    t.Skip("RLS context test requires a non-superuser database role")
}
```

Но Postgres-сервис в CI (`.github/workflows/ci.yaml`) поднимается с `POSTGRES_USER: envplane` — при инициализации через официальный образ `postgres:16` этот пользователь создаётся как **суперпользователь**, для которого `FORCE ROW LEVEL SECURITY` не действует вовсе (Postgres всегда даёт суперпользователю полный доступ, независимо от политик). То есть тест либо скипается (если это распознаётся), либо — что хуже — проходит «зелёным» без реальной проверки RLS-поведения, если проверка `isSuperuser` некорректна для этой конфигурации. Дополнительно файл собран под `//go:build integration`, и соответствующий шаг CI (`go test -tags integration ./...`) выполняется только `if: github.ref == 'refs/heads/main' && github.event_name == 'push'` — то есть **никогда на pull request**.

**Сценарий отказа:** если в будущем кто-то случайно вернёт прямой `s.db.Query`/`.QueryRow`/`.QueryContext` в один из этих методов, единственный тест, специально написанный для обнаружения именно этого регресса, не даст сигнала — ни на PR (не запускается), ни на push в main (скипается из-за роли).

**2. Regex-guard в `check-tenant-scope.sh` покрывает не все методы `*sql.DB`.** Текущий паттерн:

```bash
'\.(db|parent\.db)\.(Query|Exec)\(' internal/store
```

Ловит только `.Query(`/`.Exec(`, но не `.QueryRow(`, `.QueryContext(`, `.ExecContext(`, `.QueryRowContext(`. Пример уже существующего необнаруженного случая — `internal/store/identity_store.go:38,47`, где `s.db.QueryRow(...)` используется напрямую для таблицы `users`, в обход `tenant_tx.go`-хелперов, и текущий guard этого не замечает (не в рамках EP-ARCH-062, но иллюстрирует дыру в самом guard'е).

## Требуемая реализация

1. Заменить условие само-скипа теста RLS на явную настройку тестовой роли: создавать (или требовать через переменную окружения) отдельную non-superuser роль специально для этого теста в CI, а не полагаться на роль, под которой поднят весь тестовый Postgres-инстанс.
2. Убрать ограничение `if: github.ref == 'refs/heads/main' && github.event_name == 'push'` для integration-тестов, покрывающих RLS-поведение (как минимум для конкретно этого теста — вынести его в отдельный always-on шаг CI, если полный integration-suite по каким-то причинам должен оставаться main-only), либо явно перепроверить и задокументировать, почему это приемлемо (например, если PR-CI по другим причинам не может поднять реальную Postgres — но текущий Postgres-сервис в `ci.yaml` уже используется где-то ещё для не-RLS тестов, что делает этот аргумент маловероятным).
3. Расширить regex в `check-tenant-scope.sh` до `\.(db|parent\.db)\.(Query|Exec|QueryRow|QueryContext|ExecContext|QueryRowContext)\(`.
4. Явно проверить (и, если необходимо, отдельным тикетом зафиксировать) статус `internal/store/identity_store.go:38,47` — соответствует ли прямой `QueryRow` там ожидаемому дизайну (возможно, таблица `users` не тенант-специфична и это осознанно, но это стоит подтвердить, а не просто игнорировать по факту того, что guard его не ловит).

## Что НЕ входит в этот тикет

Полный аудит всех мест использования `*sql.DB` в `internal/store` — только исправление механизмов защиты (тест + regex), которые должны такие места ловить.

## Критерии приёмки

- Тест RLS-поведения `ListTenantIDs()` реально выполняется под non-superuser ролью хотя бы в одном регулярно запускаемом CI-шаге (в идеале — на каждый PR).
- `check-tenant-scope.sh` ловит `QueryRow`/`QueryContext`/`ExecContext`/`QueryRowContext` в дополнение к `Query`/`Exec`.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные, включая новую конфигурацию CI-роли.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/control-plane

Задача: аддендум к EP-ARCH-062. Регрессионный тест TestSQLListTenantIDsUsesPlatformRLSContext
(internal/store/sql_store_integration_test.go:835-882) само-скипается при роли-суперпользователе,
а Postgres-сервис в CI (.github/workflows/ci.yaml) поднимается с POSTGRES_USER: envplane, который
на официальном образе postgres:16 создаётся суперпользователем — то есть тест либо скипается, либо
не отражает реальное RLS-поведение под обычной ролью. Дополнительно integration-тесты (build tag
"integration") запускаются в CI только на push в main, никогда на pull request. Отдельно,
scripts/check-tenant-scope.sh:19-20 ловит только буквальные ".Query(" и ".Exec(" после ".db"/
".parent.db", но не ".QueryRow(", ".QueryContext(", ".ExecContext(", ".QueryRowContext(" — то есть
будущий обход tenant_tx.go через эти методы не будет пойман ни тестом (не выполняется как надо),
ни regex-guard'ом.

Нужно:
1. Настроить в CI отдельную non-superuser роль специально для RLS-теста, не полагаясь на роль
   всего Postgres-сервиса.
2. Убедиться, что этот RLS-тест реально выполняется на каждый PR, а не только на push в main.
3. Расширить regex в check-tenant-scope.sh до
   \.(db|parent\.db)\.(Query|Exec|QueryRow|QueryContext|ExecContext|QueryRowContext)\(
4. Проверить internal/store/identity_store.go:38,47 (прямой QueryRow для таблицы users) — уже
   существующий случай, не пойманный текущим guard'ом — подтвердить, что это осознанное решение,
   а не пропуск.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
