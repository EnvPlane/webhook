# EP-ARCH-066 — `ResolveProjectTenant` выполняет O(число тенантов) транзакций на каждый вызов, теперь реально нагружая горячий heartbeat-путь

| Поле | Значение |
|---|---|
| Severity | High |
| Направление | reliability / performance |
| Репозиторий | `control-plane` |
| Затронутый слой | `internal/app/project_service.go:87-114` (`ResolveProjectTenant`), `internal/app/bootstrap_session_service.go` (8 точек вызова как `tenantResolver`), `internal/server/server_agent_runtime.go` (heartbeat, интервал по умолчанию 30 сек) |
| Зависит от | Побочный эффект фикса [EP-ARCH-062](../ep-arch/EP-ARCH-062-listtenantids-rls-silent-empty-result.md)/[EP-ARCH-063](../ep-arch/EP-ARCH-063-agent-heartbeat-still-unscoped-addendum-054.md) — код `ResolveProjectTenant` не менялся, но раньше был «тихо сломан» и не выполнял реальную работу |
| Статус верификации | Обнаружено и подтверждено независимым агентом верификации 7 сентября 2026 при проверке EP-ARCH-062/063, коммит `ad0bf6d` |

## Контекст

До исправления EP-ARCH-062 `ListTenantIDs()` под RLS всегда молча возвращал пустой список, из-за чего `ResolveProjectTenant` (`internal/app/project_service.go:87-114`) — функция, ищущая, какому тенанту принадлежит `projectID`, перебирая `ListTenantIDs()` и проверяя каждый — фактически не находила совпадений и почти сразу возвращала `domain.DefaultTenantID` как fallback. То есть эта функция была «тихо сломана», но дёшева по стоимости выполнения.

После фикса EP-ARCH-062/063 `ListTenantIDs()` реально возвращает всех тенантов, и `ResolveProjectTenant` наконец выполняет задуманную логику: один `platformQueryRows`-вызов (полное сканирование списка тенантов) плюс до **N** отдельных транзакционных `GetProjectForTenant` (`tenantQueryRow`, каждая — собственные `BEGIN`/`SET LOCAL`/`SELECT`/`COMMIT`) для проверки, какому тенанту в реальности принадлежит `projectID`.

Эта функция подключена как `tenantResolver` практически во всех методах `BootstrapSessionService` (`Get`, `GetStored`, `Update`, `Delete`, `CreateWithInitialData`, `StoredCredential`, `RepairPrematureCompiledForResourceScan`, `RepairCompiledFixtureDeploymentContract` — `internal/app/bootstrap_session_service.go`, 8 точек вызова), которые вызываются из 30+ обработчиков по `internal/server` — включая `agentHeartbeat`/аналогичный runner-heartbeat, приходящий по умолчанию каждые 30 секунд от каждого зарегистрированного агента/runner'а.

**Сценарий отказа:** по мере роста числа тенантов на платформе (десятки–сотни–тысячи) каждый heartbeat каждого агента/runner'а превращается в один запрос по всем тенантам плюс до N последовательных отдельных транзакций к Postgres — то есть нагрузка на БД от одной только фоновой heartbeat-активности растёт линейно с числом тенантов, умноженным на число активных агентов/runner'ов, а не остаётся постоянной. Это может создать заметную деградацию латентности и рост нагрузки на Postgres именно по мере роста платформы — иронично, ровно там, где тенант-изоляция (RLS) была нужна больше всего.

## Требуемая реализация

1. Заменить итеративный перебор тенантов в `ResolveProjectTenant` одним прямым запросом вида `SELECT DISTINCT tenant_id FROM projects WHERE id=$1` (или per-store эквивалент), выполняемым один раз под `envplane.platform=true`, вместо `ListTenantIDs()` + цикл по `GetProjectForTenant`.
2. Если такой метод пока отсутствует в интерфейсе `ProjectStore`, добавить его (`ResolveTenantForProjectID` или аналог) как часть стораджа, а не логики уровня `internal/app`.
3. Добавить бенчмарк/нагрузочный тест, демонстрирующий, что стоимость `ResolveProjectTenant` не растёт линейно с числом тенантов на платформе.
4. Рассмотреть добавление короткоживущего кэша (`projectID → tenantID`) на уровне процесса для горячих путей вроде heartbeat, если даже однозапросное решение окажется недостаточно дешёвым при очень высокой частоте heartbeat — этот пункт опционален и оценивается по факту профилирования.

## Что НЕ входит в этот тикет

Изменение самой модели данных (составные ключи `(tenant_id, id)`, обсуждавшиеся в других тикетах) — здесь фиксируется только неэффективность конкретного алгоритма резолва, при существующей схеме БД.

## Критерии приёмки

- `ResolveProjectTenant` выполняет не более одного SQL-запроса на вызов вне зависимости от числа тенантов на платформе.
- Добавлен тест/бенчмарк, подтверждающий постоянную (не растущую с числом тенантов) стоимость вызова.
- `go build ./...`, `go vet ./...`, `go test ./...` — зелёные.

## Промт для реализации в codex

```text
Репозиторий: EnvPlane/control-plane

Задача: internal/app/project_service.go:87-114, функция ResolveProjectTenant ищет тенанта для
данного projectID, вызывая ListTenantIDs() (один platformQueryRows-запрос, возвращающий полный
список тенантов) и затем для каждого тенанта отдельно вызывая GetProjectForTenant (tenantQueryRow,
отдельная транзакция BEGIN/SET LOCAL/SELECT/COMMIT на каждый тенант), пока не найдёт совпадение.
После недавнего фикса EP-ARCH-062 (ListTenantIDs теперь реально работает под RLS, а не молча
возвращает пустой список) эта функция стала реально выполнять весь этот O(N) перебор на каждый
вызов. Она подключена как tenantResolver в internal/app/bootstrap_session_service.go (8 точек
вызова: Get, GetStored, Update, Delete, CreateWithInitialData, StoredCredential,
RepairPrematureCompiledForResourceScan, RepairCompiledFixtureDeploymentContract), которые
вызываются из 30+ обработчиков в internal/server, включая heartbeat-путь агентов/runner'ов
(интервал по умолчанию 30 секунд). По мере роста числа тенантов нагрузка на Postgres от одной
только фоновой heartbeat-активности растёт линейно.

Нужно: заменить итеративный перебор одним прямым SQL-запросом вида
"SELECT DISTINCT tenant_id FROM projects WHERE id=$1", выполняемым один раз под
envplane.platform=true (через platformQueryRow/аналог), вместо ListTenantIDs()+цикл по
GetProjectForTenant. Добавить такой метод в интерфейс ProjectStore, если его ещё нет. Добавить
бенчмарк/тест, подтверждающий, что стоимость ResolveProjectTenant не растёт с числом тенантов.

Ограничения: комментарии в коде только на английском, не запускай git push самостоятельно.
Проверка: go build ./..., go vet ./..., go test ./...
```
